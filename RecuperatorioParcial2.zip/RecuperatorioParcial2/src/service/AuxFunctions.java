
package service;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;

public class AuxFunctions {
    public static void checkearNull(Object o){
        if (o == null){
            throw new IllegalArgumentException("Parametro null no permitido");
        }
    }
    
    public static void validarIndice(int indice, List<?> lista){
        if (indice < 0 || indice >= lista.size()){
            throw new IndexOutOfBoundsException("El indice esta fuera de rango");
        }
    }
    
    public static void checkearArchivoExiste(File archivo) throws FileNotFoundException{
        if (!archivo.exists()){
            throw new FileNotFoundException("El archivo especificado no existe");
        }
    }
}
