
package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public class GestorEventos<T extends CSVSerializable> implements Gestionable<T> {
    private List<T> items = new ArrayList<>();
    
//metodos basicas
    @Override
    public void agregar(T item) {
        AuxFunctions.checkearNull(item);
        items.add(item);
    }

    @Override
    public void eliminar(int indice) {
        AuxFunctions.validarIndice(indice, items);
        items.remove(indice);
    }

    @Override
    public T obtener(int indice) {
        AuxFunctions.validarIndice(indice, items);
        return items.get(indice);
    }

    @Override
    public void limpiar() {
        items.clear();
    }

//metodos que usan interfaces funcionales
    @Override
    public void ordenar() {
        ordenar((Comparator <T>)Comparator.naturalOrder());
    }
    
    @Override
    public void ordenar(Comparator<T> comparador) {
        AuxFunctions.checkearNull(comparador);
        items.sort(comparador);
    }

    @Override
    public List<T> filtrar(Predicate<T> predicado) {
        AuxFunctions.checkearNull(predicado);
        
        List<T> filtrados = new ArrayList<>();
        for (T item: items){
            if(predicado.test(item)){
                filtrados.add(item);
            }
        }
        return filtrados;
    }

//metodos de guardado y carga
    @Override
    public void guardarEnBinario(String path) {
        AuxFunctions.checkearNull(path);
        
        try(ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))){
            salida.writeObject(items);
        } catch (IOException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String path) throws FileNotFoundException{
        AuxFunctions.checkearNull(path);
        
        //valdar que el archivo existe
        File archivoSerial = new File(path);
        AuxFunctions.checkearArchivoExiste(archivoSerial);
        
        try(ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(archivoSerial))){
            items.addAll((List<T>) entrada.readObject());
        } catch (IOException | ClassNotFoundException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void guardarEnCSV(String path) {
        AuxFunctions.checkearNull(path);
        
        try(BufferedWriter escritor = new BufferedWriter(new FileWriter(path))){
            escritor.write(items.get(0).headerCSV() + "\n"); //header del csv
            for (T item: items){
                escritor.write(item.toCSV() + "\n");
            }
        } catch (IOException e){
            System.out.println(e.getMessage());
        }
    }

    @Override
    public void cargarDesdeCSV(String path, Function<String, T> deserializadorDeCSV) throws FileNotFoundException{
        AuxFunctions.checkearNull(path);
            
        //valdar que el archivo existe
        File archivoCSV = new File(path);
        AuxFunctions.checkearArchivoExiste(archivoCSV);
        
        try(BufferedReader lector = new BufferedReader(new FileReader(path))){
            lector.readLine();
            String lineaCSV;
            while((lineaCSV = lector.readLine()) != null){
                items.add(deserializadorDeCSV.apply(lineaCSV));
            }
            
        } catch (IOException e){
            System.out.println(e.getMessage());
        }
    }
    
    @Override
    public void mostrarTodos(){
        for(T item: items){
            System.out.println(item);
        }
    }
}
