
package service;

import java.io.FileNotFoundException;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;


public interface Gestionable<T extends CSVSerializable> {
    void agregar(T item);
    
    void eliminar(int indice);
    
    T obtener(int indice);
    
    void limpiar();
    
    void ordenar();
    
    void ordenar(Comparator<T> comparador);
    
    List<T> filtrar(Predicate<T> predicado);
    
    public void guardarEnBinario(String path);
    
    public void cargarDesdeBinario(String path) throws FileNotFoundException;
    
    public void guardarEnCSV(String path);
    
    public void cargarDesdeCSV(String path, Function<String, T> deserializadorDeCSV) throws FileNotFoundException;
    
    public void mostrarTodos();
}
