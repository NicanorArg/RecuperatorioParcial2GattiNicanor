
package model;

import java.time.LocalDate;
import service.AuxFunctions;

public class EventoMusical extends Evento {
    private static final int CANTIDAD_DE_ATRIBUTOS = 5;
    private static final long SerialVersionIUD = 1L;
    
    private String artista;
    private GeneroMusical genero;

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    @Override
    public String toString() {
        return super.toString() + ", Artista: " + artista + ", Genero: " + genero.toString().toLowerCase(); 
    }

    @Override
    public String toCSV() {
        return super.toCSV() + "," + artista + "," + genero.toString(); 
    }
    
    public static EventoMusical fromCSV(String lineaCSV){
        //validacion de lineaCSV y division de esta
        AuxFunctions.checkearNull(lineaCSV);
        
        if (lineaCSV.endsWith("\n")){
            lineaCSV = lineaCSV.substring(0, lineaCSV.length() - 1);
        }
        //validacion de cantidad de elementos
        String[] atributos = lineaCSV.split(",");
        if (atributos.length != CANTIDAD_DE_ATRIBUTOS){
            throw new IllegalArgumentException("La linea CSV no posee la cantidad correcta de elementos");
        }
        
        return new EventoMusical(
            Integer.parseInt(atributos[0]),         //Id
            atributos[1],                           //nombre
            LocalDate.parse(atributos[2]),          //fecha
            atributos[3],                           //artista
            GeneroMusical.valueOf(atributos[4]));   //genero
    }
    
    @Override
    public String headerCSV(){
        return super.headerCSV() + ",artista,genero";
    }
}
