
package model;

import java.io.Serializable;
import java.time.LocalDate;
import service.CSVSerializable;

public abstract class Evento implements Comparable<Evento>, CSVSerializable, Serializable{
    private int id;
    private String nombre;
    private LocalDate fecha;

    public Evento(int id, String nombre, LocalDate fecha) {
        this.id = id;
        this.nombre = nombre;
        this.fecha = fecha;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Nombre: " + nombre + ", Fecha: " + fecha.toString();
    }

    //orden natural de eventos es por fecha
    @Override
    public int compareTo(Evento e){
        return fecha.compareTo(e.fecha);
    };

    @Override
    public String toCSV(){
        return id + "," + nombre + "," + fecha;
    };
    
    @Override
    public String headerCSV(){
        return "id,nombre,fecha";
    }
    
}
