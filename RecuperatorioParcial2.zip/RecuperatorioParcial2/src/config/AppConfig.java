
package config;

public class AppConfig {
    public static final String PATH = "src/data/";
    public static final String PATH_CSV = PATH + "eventosMusicales.csv";
    public static final String PATH_SER = PATH + "eventosMusicales.ser";
}
